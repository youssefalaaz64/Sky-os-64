MODDIR="$(find/data/adb -type d -name s25ultramodule)"

echo "s25ultramodule by Youssef ALAA flagship phone!!"