MODDIR="$(find /data/adb -type d -name myfirstmodule)"

echo "One ui 8 sounds on custom roms (color os origin os hyper os miui crdroid  under android 9)"